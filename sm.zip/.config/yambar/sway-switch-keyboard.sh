#!/bin/sh
swaymsg input '*' xkb_switch_layout next
