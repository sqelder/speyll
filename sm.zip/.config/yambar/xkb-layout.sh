#!/bin/sh

layout=$(echo $XKB_DEFAULT_LAYOUT)
echo "xkb_layout|string|$layout"
echo ""
